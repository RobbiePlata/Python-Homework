import turtle

turtle.penup()
turtle.goto(0, 100 / 2)
turtle.pendown()

turtle.right(72)
turtle.forward(100)

turtle.right(144)
turtle.forward(100)

turtle.right(144)
turtle.forward(100)

turtle.right(144)
turtle.forward(100)

turtle.right(144)
turtle.forward(100)

input("Press any key to exit...")
# Prompt the user to enter three numbers
strNumber1 = input("Enter the first number: ")
strNumber2 = input("Enter the second number: ")
number1=float(strNumber1)
number2=float(strNumber2)

# Compute average
average = (number1 + number2) / 2

# Display result
print("The average of", number1, number2,  
    "is", average)
